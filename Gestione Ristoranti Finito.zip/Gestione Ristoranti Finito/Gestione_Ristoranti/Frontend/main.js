document.addEventListener("DOMContentLoaded", () => {
    const container = document.getElementById("ristoranti-container");
    const loginBtn = document.getElementById("login-btn");
    const registerBtn = document.getElementById("register-btn");
    const logoutBtn = document.getElementById("logout-btn");
    const benvenuto = document.getElementById("benvenuto");

    fetch("../backend/api/session.php")
        .then(res => res.json())
        .then(data => {
            if (data.loggedIn) {
                loginBtn.style.display = "none";
                registerBtn.style.display = "none";
                logoutBtn.style.display = "inline-block";
                benvenuto.textContent = `👋 Benvenuto, ${data.nome}`;
            } else {
                loginBtn.style.display = "inline-block";
                registerBtn.style.display = "inline-block";
                logoutBtn.style.display = "none";
                benvenuto.textContent = "";
            }
        });

    logoutBtn.addEventListener("click", () => {
        fetch("../backend/api/logout.php")
            .then(() => location.reload());
    });

    // Caricamento ristoranti (già funzionante)
    fetch("../backend/api/ristoranti.php")
        .then(response => response.json())
        .then(data => {
            if (Array.isArray(data)) {
                data.forEach(ristorante => {
                    const card = document.createElement("div");
                    card.className = "card";
                    card.innerHTML = `
                        <h2>${ristorante.nome}</h2>
                        <p>📍 ${ristorante.indirizzo}</p>
                        <p>📞 ${ristorante.telefono}</p>
                        <p>📧 ${ristorante.email}</p>
                        <p>🪑 Posti max: ${ristorante.capacita_max}</p>
                    `;
                    container.appendChild(card);
                });
            } else {
                container.innerHTML = "<p>Nessun ristorante disponibile.</p>";
            }
        })
        .catch(error => {
            container.innerHTML = "<p>Errore nel caricamento dei ristoranti.</p>";
            console.error("Errore:", error);
        });
});
