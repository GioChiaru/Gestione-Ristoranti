document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("prenota-form");
  const confermaBox = document.getElementById("conferma-prenotazione");
  const dettagli = document.getElementById("dettagli-prenotazione");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const formData = new FormData(form);
    const dati = Object.fromEntries(formData.entries());

    try {
      const response = await fetch("../backend/api/prenotazioni.php?action=create", {
        method: "POST",
        body: formData,
      });

      const result = await response.json();

      if (result.success) {
        form.style.display = "none";
        confermaBox.style.display = "block";

        dettagli.innerHTML = `
          <strong>Ristorante ID:</strong> ${dati.ristorante_id}<br>
          <strong>Nome:</strong> ${dati.nome_cliente}<br>
          <strong>Telefono:</strong> ${dati.telefono}<br>
          <strong>Email:</strong> ${dati.email}<br>
          <strong>Data:</strong> ${dati.data}<br>
          <strong>Ora:</strong> ${dati.ora}<br>
          <strong>Numero persone:</strong> ${dati.numero_persone}
        `;
      } else {
        alert("Errore nella prenotazione: " + result.message);
      }
    } catch (error) {
      console.error("Errore:", error);
      alert("Errore nella comunicazione con il server.");
    }
  });
});
