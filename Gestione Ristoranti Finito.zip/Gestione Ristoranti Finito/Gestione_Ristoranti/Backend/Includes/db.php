<?php
$host = 'localhost';
$user = 'root';
$password = '';
$database = 'gestione_ristoranti';

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die(json_encode(["success" => false, "message" => "Connessione fallita: " . $conn->connect_error]));
}
?>
