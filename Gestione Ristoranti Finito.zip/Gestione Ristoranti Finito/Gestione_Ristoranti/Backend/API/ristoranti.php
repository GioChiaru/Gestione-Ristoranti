<?php
header('Content-Type: application/json');
session_start();

require_once('../includes/db.php'); // Assicurati che questo percorso sia corretto

// Query per recuperare i ristoranti
$sql = "SELECT * FROM ristoranti";
$result = $conn->query($sql); // usa $conn, non $pdo

$ristoranti = [];

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $ristoranti[] = $row;
    }
}

echo json_encode($ristoranti);
?>
