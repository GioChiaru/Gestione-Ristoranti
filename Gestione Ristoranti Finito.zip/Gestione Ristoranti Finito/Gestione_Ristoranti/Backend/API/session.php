<?php
session_start();
header('Content-Type: application/json');

if (isset($_SESSION['utente_id'])) {
    echo json_encode([
        'loggedIn' => true,
        'nome' => $_SESSION['nome'],
        'ruolo' => $_SESSION['ruolo']
    ]);
} else {
    echo json_encode(['loggedIn' => false]);
}
