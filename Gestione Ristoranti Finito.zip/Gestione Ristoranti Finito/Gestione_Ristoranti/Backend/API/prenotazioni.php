<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();

header('Content-Type: application/json');

require_once '../includes/db.php'; // supponendo che qui sia definito $conn come mysqli

$action = $_GET['action'] ?? '';

if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $ristorante_id = $_POST['ristorante_id'] ?? '';
    $nome_cliente = $_POST['nome_cliente'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $email = $_POST['email'] ?? '';
    $data = $_POST['data'] ?? '';
    $ora = $_POST['ora'] ?? '';
    $numero_persone = $_POST['numero_persone'] ?? '';

    if (empty($ristorante_id) || empty($nome_cliente) || empty($telefono) || empty($email) || empty($data) || empty($ora) || empty($numero_persone)) {
        echo json_encode(['success' => false, 'message' => 'Compila tutti i campi']);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO prenotazioni (ristorante_id, nome_cliente, telefono, email, data, ora, numero_persone) VALUES (?, ?, ?, ?, ?, ?, ?)");
    if (!$stmt) {
        echo json_encode(['success' => false, 'message' => 'Errore preparazione query: ' . $conn->error]);
        exit;
    }

    $stmt->bind_param("isssssi", $ristorante_id, $nome_cliente, $telefono, $email, $data, $ora, $numero_persone);
    $ok = $stmt->execute();

    if (!$ok) {
        echo json_encode(['success' => false, 'message' => 'Errore esecuzione query: ' . $stmt->error]);
    } else {
        echo json_encode(['success' => true, 'message' => 'Prenotazione effettuata']);
    }

    $stmt->close();
    exit;
}

if ($action === 'list' && $_SERVER['REQUEST_METHOD'] === 'GET') {
    $result = $conn->query("SELECT * FROM prenotazioni ORDER BY data DESC, ora DESC");
    if (!$result) {
        echo json_encode(['success' => false, 'message' => 'Errore DB: ' . $conn->error]);
        exit;
    }

    $prenotazioni = [];
    while ($row = $result->fetch_assoc()) {
        $prenotazioni[] = $row;
    }

    echo json_encode(['success' => true, 'data' => $prenotazioni]);
    exit;
}

echo json_encode(['success' => false, 'message' => 'Azione non valida']);
