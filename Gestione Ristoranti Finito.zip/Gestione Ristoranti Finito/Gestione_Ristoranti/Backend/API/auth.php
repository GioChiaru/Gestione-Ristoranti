<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
header('Content-Type: application/json');

require_once '../includes/db.php'; // include $conn (mysqli)

$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && $action === 'ristoranti') {
    // Questo lo lasci solo se vuoi restituire la lista ristoranti da qui, altrimenti togli
    $sql = "SELECT nome, indirizzo, telefono, email, capacita_max FROM ristoranti";
    $result = $conn->query($sql);
    if ($result) {
        $ristoranti = [];
        while ($row = $result->fetch_assoc()) {
            $ristoranti[] = $row;
        }
        echo json_encode($ristoranti);
    } else {
        echo json_encode(['success' => false, 'message' => 'Errore DB: ' . $conn->error]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit;
}

if ($action === 'register') {
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $ruolo = $_POST['ruolo'] ?? '';

    if (empty($nome) || empty($email) || empty($password) || empty($ruolo)) {
        echo json_encode(['success' => false, 'message' => 'Compila tutti i campi']);
        exit;
    }

    // Controlla se email esiste già
    $stmt = $conn->prepare("SELECT id FROM utenti WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Email già registrata']);
        exit;
    }
    $stmt->close();

    // Inserisci utente
    $hashed = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO utenti (nome, email, password, ruolo) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $nome, $email, $hashed, $ruolo);
    $ok = $stmt->execute();
    $stmt->close();

    echo json_encode(['success' => $ok, 'message' => $ok ? 'Registrazione completata' : 'Errore nella registrazione']);
    exit;
}

if ($action === 'login') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Inserisci email e password']);
        exit;
    }

    $stmt = $conn->prepare("SELECT id, nome, password, ruolo FROM utenti WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $utente = $result->fetch_assoc();
    $stmt->close();

    if ($utente && password_verify($password, $utente['password'])) {
        $_SESSION['utente_id'] = $utente['id'];
        $_SESSION['ruolo'] = $utente['ruolo'];
        $_SESSION['nome'] = $utente['nome'];
        echo json_encode(['success' => true, 'message' => 'Accesso riuscito']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Credenziali non valide']);
    }
    exit;
}

// Se l'azione non è riconosciuta
echo json_encode(['success' => false, 'message' => 'Azione non valida']);
