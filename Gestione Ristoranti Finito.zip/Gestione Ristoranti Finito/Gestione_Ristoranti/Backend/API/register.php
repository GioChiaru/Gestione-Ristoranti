<?php
session_start();
header("Content-Type: application/json");

$mysqli = new mysqli("localhost", "root", "", "gestione_ristoranti");

if ($mysqli->connect_error) {
    echo json_encode(["success" => false, "message" => "Errore di connessione al database"]);
    exit;
}

// Recupero i dati con POST
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$ruolo = $_POST['ruolo'] ?? 'utente'; // opzionale

// Controllo campi obbligatori
if (!$nome || !$email || !$password) {
    echo json_encode(["success" => false, "message" => "Tutti i campi sono obbligatori"]);
    exit;
}

// Controllo se email già esistente
$stmt = $mysqli->prepare("SELECT id FROM utenti WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(["success" => false, "message" => "Email già registrata"]);
    exit;
}

// Cripta password e inserisce utente
$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $mysqli->prepare("INSERT INTO utenti (nome, email, password, ruolo) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nome, $email, $hash, $ruolo);
$success = $stmt->execute();

if ($success) {
    echo json_encode(["success" => true, "message" => "Registrazione completata"]);
} else {
    echo json_encode(["success" => false, "message" => "Errore nella registrazione"]);
}
