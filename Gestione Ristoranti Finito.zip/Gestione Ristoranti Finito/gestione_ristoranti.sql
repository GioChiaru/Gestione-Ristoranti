-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Mag 20, 2025 alle 22:51
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gestione_ristoranti`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `prenotazioni`
--

CREATE TABLE `prenotazioni` (
  `id` int(11) NOT NULL,
  `ristorante_id` int(11) NOT NULL,
  `nome_cliente` varchar(100) NOT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `data` date NOT NULL,
  `ora` time NOT NULL,
  `numero_persone` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `prenotazioni`
--

INSERT INTO `prenotazioni` (`id`, `ristorante_id`, `nome_cliente`, `telefono`, `email`, `data`, `ora`, `numero_persone`) VALUES
(1, 1, '23er', '1234567', 'h@h', '0001-01-01', '01:01:00', 1);

-- --------------------------------------------------------

--
-- Struttura della tabella `ristoranti`
--

CREATE TABLE `ristoranti` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `indirizzo` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `capacita_max` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `ristoranti`
--

INSERT INTO `ristoranti` (`id`, `nome`, `indirizzo`, `telefono`, `email`, `capacita_max`) VALUES
(1, 'Trattoria da Mario', 'Via Roma 12, Milano', '02 1234567', 'info@trattoriamario.it', 50),
(2, 'La Pergola', 'Via del Corso 45, Roma', '06 7654321', 'contatti@lapergola.it', 80),
(3, 'Osteria del Gusto', 'Piazza Garibaldi 10, Napoli', '081 2345678', 'prenotazioni@osteriadelgusto.it', 40),
(4, 'Il Mare In Tavola', 'Lungomare 22, Genova', '010 5678910', 'info@ilmareintavola.it', 60),
(5, 'Pizzeria Bella Napoli', 'Via Vesuvio 8, Napoli', '081 8765432', 'info@bellanapoli.it', 100),
(6, 'Ristorante Al Castello', 'Via Castello 33, Firenze', '055 3456789', 'info@alcastello.it', 70),
(7, 'Sapori di Sicilia', 'Via Etnea 101, Catania', '095 1239876', 'contatto@saporidisicilia.it', 55),
(8, 'La Griglia di Bacco', 'Viale dei Vini 17, Verona', '045 3214567', 'prenota@grigliadibacco.it', 85),
(9, 'Veg&Go', 'Corso Libertà 20, Torino', '011 5432190', 'info@vegandgo.it', 35);

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `ruolo` enum('admin','cliente') DEFAULT 'cliente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id`, `nome`, `email`, `password`, `ruolo`) VALUES
(1, 'gg', 'ggg@gggg', '$2y$10$jAm5emYb04O0b/nzPbywouodeGXS4hNLOc81.D9oGr4jng.ws031e', ''),
(2, 'marco', 'mar@o', '$2y$10$OqcL/frVcW2sC3RYj/Qz9.l2MAJm39ry9QDAf4mGsL50ILcXF7mea', '');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `prenotazioni`
--
ALTER TABLE `prenotazioni`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ristorante_id` (`ristorante_id`);

--
-- Indici per le tabelle `ristoranti`
--
ALTER TABLE `ristoranti`
  ADD PRIMARY KEY (`id`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `prenotazioni`
--
ALTER TABLE `prenotazioni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `ristoranti`
--
ALTER TABLE `ristoranti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `prenotazioni`
--
ALTER TABLE `prenotazioni`
  ADD CONSTRAINT `prenotazioni_ibfk_1` FOREIGN KEY (`ristorante_id`) REFERENCES `ristoranti` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
